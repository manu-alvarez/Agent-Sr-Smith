# Qué hay en este ZIP

Scaffolding completo de Sr.Smith, con el contenido real de cada archivo.

- La raíz, src/, docs/, prompts/, schemas/, config/, ai/ y tests/ son el plano de control.
- proyectos/mi-proyecto/ es un proyecto de ejemplo con todos los entornos.
- agente/ es el agente Full.
- misiones/mision/ es una misión de ejemplo.

Habilidades: 14. Capacidades: 18. Skills: 28. Herramientas: 15.

No incluye node_modules ni bases de datos locales.
