# Misión de ejemplo

Proyecto: mi-proyecto
Perfil: Construir

## Objetivo

Una lista de gastos que sigue ahí al recargar.

## Hecho cuando

- Añado un gasto y sigue en la lista tras recargar.
- npm test pasa.
