# Borrador del modelo

Este archivo solo aparece cuando Ollama responde. Aquí va el alcance, los archivos, las pruebas y los riesgos que redacte el modelo.
