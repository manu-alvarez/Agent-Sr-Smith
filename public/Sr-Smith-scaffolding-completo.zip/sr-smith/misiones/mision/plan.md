# Plan

1. Escribir la prueba que falla.
2. Guardar el gasto en la carpeta del proyecto.
3. Volver a ejecutar npm test.
