import type { ProfileId } from "../../core/domain/index.ts";

export interface ProfileDefinition {
  id: ProfileId;
  name: string;
  summary: string;
  roles: string[];
  tools: string[];
  capabilities: string[];
  limits: { maxSteps: number; maxParallel: number; timeoutMs: number };
}

export const PROFILES: ProfileDefinition[] = [
  {
    id: "research",
    name: "Research X",
    summary: "Investiga un tema, cita lo que encuentra y no escribe el programa hasta que la pregunta esté respondida.",
    roles: ["planner", "researcher", "knowledge-engineer", "evaluator", "watchdog"],
    tools: ["knowledge.search", "memory.recall", "memory.remember"],
    capabilities: ["research", "citation", "synthesis"],
    limits: { maxSteps: 24, maxParallel: 3, timeoutMs: 180_000 },
  },
  {
    id: "engineering",
    name: "Engineering X",
    summary: "Diseña, programa en la carpeta del proyecto, prueba y deja que otra parte revise el resultado.",
    roles: [
      "planner",
      "architect",
      "principal-engineer",
      "developer",
      "qa-engineer",
      "reviewer",
      "evaluator",
      "watchdog",
    ],
    tools: ["workspace.read", "workspace.write", "knowledge.search"],
    capabilities: ["design", "implementation", "verification"],
    limits: { maxSteps: 36, maxParallel: 4, timeoutMs: 240_000 },
  },
  {
    id: "autonomous",
    name: "Autonomous X",
    summary: "Sigue una tarea larga, guarda el avance y retoma si el proceso se corta.",
    roles: [
      "orchestrator",
      "planner",
      "developer",
      "qa-engineer",
      "watchdog",
      "recovery-agent",
      "evaluator",
    ],
    tools: ["workspace.read", "workspace.write", "memory.remember"],
    capabilities: ["checkpoint", "recovery", "long-running"],
    limits: { maxSteps: 48, maxParallel: 4, timeoutMs: 300_000 },
  },
  {
    id: "security",
    name: "Security X",
    summary: "Revisa quién puede hacer qué, qué datos se tocan y qué no debe poder ocurrir.",
    roles: ["planner", "security-engineer", "systems-engineer", "reviewer", "evaluator", "watchdog"],
    tools: ["policy.explain", "workspace.read", "knowledge.search"],
    capabilities: ["threat-model", "least-privilege"],
    limits: { maxSteps: 28, maxParallel: 3, timeoutMs: 180_000 },
  },
  {
    id: "full",
    name: "Sr.Smith Full",
    summary: "Entran todos los roles. Úsalo cuando no quieras dejar fuera ninguna parte del trabajo.",
    roles: [
      "orchestrator",
      "planner",
      "architect",
      "researcher",
      "principal-engineer",
      "developer",
      "systems-engineer",
      "security-engineer",
      "debugger",
      "qa-engineer",
      "reviewer",
      "performance-engineer",
      "devops-engineer",
      "data-engineer",
      "knowledge-engineer",
      "documentation-engineer",
      "evaluator",
      "watchdog",
      "recovery-agent",
    ],
    tools: ["workspace.read", "workspace.write", "knowledge.search", "memory.recall", "policy.explain"],
    capabilities: ["planning", "implementation", "research", "security", "recovery"],
    limits: { maxSteps: 64, maxParallel: 4, timeoutMs: 360_000 },
  },
  {
    id: "headless",
    name: "Headless X",
    summary: "Un comando de terminal, sin pantalla.",
    roles: ["planner", "developer", "qa-engineer", "evaluator", "watchdog"],
    tools: ["workspace.read", "workspace.write"],
    capabilities: ["cli", "verification"],
    limits: { maxSteps: 24, maxParallel: 2, timeoutMs: 180_000 },
  },
  {
    id: "product",
    name: "Producto",
    summary: "Decide qué se construye, para quién, qué queda fuera y cómo se cuenta.",
    roles: ["planner", "architect", "researcher", "documentation-engineer", "evaluator"],
    tools: ["knowledge.search", "workspace.read"],
    capabilities: ["scope", "narrative"],
    limits: { maxSteps: 24, maxParallel: 3, timeoutMs: 180_000 },
  },
  {
    id: "data",
    name: "Datos",
    summary: "Modela tablas, archivos o un corpus y comprueba que los números salen de ahí.",
    roles: ["data-engineer", "knowledge-engineer", "qa-engineer", "evaluator"],
    tools: ["workspace.read", "workspace.write", "knowledge.search"],
    capabilities: ["model", "lineage"],
    limits: { maxSteps: 28, maxParallel: 3, timeoutMs: 180_000 },
  },
  {
    id: "ops",
    name: "Operación",
    summary: "Deja el proceso funcionando en local: automatiza, vigila y recupera si falla.",
    roles: ["devops-engineer", "systems-engineer", "qa-engineer", "watchdog", "recovery-agent"],
    tools: ["workspace.read", "workspace.write"],
    capabilities: ["automation", "recovery"],
    limits: { maxSteps: 32, maxParallel: 3, timeoutMs: 240_000 },
  },
];

export function profileById(id: ProfileId): ProfileDefinition {
  const found = PROFILES.find((profile) => profile.id === id);
  if (!found) throw new Error(`Unknown profile ${id}`);
  return found;
}
