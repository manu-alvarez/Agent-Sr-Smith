# mi-proyecto

Un programa que se lanza en la terminal.

Objetivo: Una lista de gastos que sigue ahí al recargar. Está hecho cuando añado uno y npm test pasa.

## Entorno

Abre esta carpeta (`sr-smith/proyectos/mi-proyecto`) con OpenCode, Codex, Antigravity, Windsurf, Copilot, Cline, Trae, Claude Code, Gemini CLI, Cursor, Continue, VS Code. Archivos: `opencode.json`, `.opencode/` y `AGENTS.md`, `CLAUDE.md`, `.cursor/rules/proyecto.mdc`, `.vscode/`.

OpenCode es el entorno principal: `opencode` en esta carpeta lee `opencode.json` y `AGENTS.md`.

## Framework

Este directorio es el proyecto. No depende del plano de control para ejecutarse.

```bash
npm install
npm test
npm start
```

## CLI del plano de control

Desde la raíz `sr-smith/`, no desde aquí:

```bash
npm install
npm test
node --experimental-strip-types src/cli/index.ts doctor
```
