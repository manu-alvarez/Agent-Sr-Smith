# mi-proyecto

Objetivo: Una lista de gastos que sigue ahí al recargar. Está hecho cuando añado uno y npm test pasa.

Trabaja solo dentro de esta carpeta. No inventes servicios, claves ni archivos que este paquete no tiene. No añadas dependencias que no estén en package.json.

Comandos reales:

```bash
npm install
npm test
npm start
```
