import assert from "node:assert/strict";
import test from "node:test";
import { describeProject } from "./main.ts";

test("describe el proyecto elegido", () => {
  const text = describeProject("mi-proyecto", "Una lista de gastos que sigue ahí al recargar. Está hecho cuando añado uno y npm test pasa.");
  assert.match(text, new RegExp("mi-proyecto"));
  assert.match(text, /\S/);
});

test("rechaza un nombre vacío", () => {
  assert.throws(() => describeProject("  ", "Una lista de gastos que sigue ahí al recargar. Está hecho cuando añado uno y npm test pasa."));
});
