export function describeProject(name: string, objective: string): string {
  const title = name.trim();
  const goal = objective.trim();
  if (!title || !goal) throw new Error("El proyecto necesita nombre y objetivo.");
  return title + ": " + goal;
}

import { pathToFileURL } from "node:url";

const entry = process.argv[1];
if (entry && import.meta.url === pathToFileURL(entry).href) {
  console.log(describeProject("mi-proyecto", "Una lista de gastos que sigue ahí al recargar. Está hecho cuando añado uno y npm test pasa."));
}
