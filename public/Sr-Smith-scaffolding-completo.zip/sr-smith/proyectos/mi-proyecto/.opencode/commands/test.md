---
description: Ejecuta npm test
agent: build
---

Ejecuta `npm test` en este proyecto. Si falla, corrige solo el fallo que muestre la prueba. No añadas dependencias.
