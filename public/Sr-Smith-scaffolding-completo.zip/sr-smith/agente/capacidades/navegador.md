# Navegador

Abre una página y lee lo que se ve.
