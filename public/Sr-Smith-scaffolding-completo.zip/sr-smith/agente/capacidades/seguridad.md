# Seguridad

Revisa permisos y datos sensibles sin explotarlos.
