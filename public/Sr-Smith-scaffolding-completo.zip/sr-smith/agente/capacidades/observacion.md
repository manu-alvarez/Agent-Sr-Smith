# Ver si está vivo

Añade una comprobación de salud o un log útil.
