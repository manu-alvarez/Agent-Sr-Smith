# Diseño

Propone la pantalla o el comando con una sola acción principal.
