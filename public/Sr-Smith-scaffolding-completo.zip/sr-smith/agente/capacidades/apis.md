# APIs

Llama a una ruta y guarda el estado y el cuerpo.
