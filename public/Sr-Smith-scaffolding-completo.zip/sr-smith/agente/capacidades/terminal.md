# Terminal

Ejecuta comandos en la carpeta y lee la salida.
