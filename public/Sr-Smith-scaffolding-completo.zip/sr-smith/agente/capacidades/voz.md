# Explicar en voz alta

Resume el estado en frases cortas que se puedan leer en alto.
