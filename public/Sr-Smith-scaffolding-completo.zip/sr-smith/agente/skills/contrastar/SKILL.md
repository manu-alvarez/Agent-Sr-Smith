---
name: contrastar
description: Contrastar. Pon juntas dos fuentes o dos opciones. Qué coincide, qué no, y cuál usas.
---

Pon juntas dos fuentes o dos opciones. Qué coincide, qué no, y cuál usas.
