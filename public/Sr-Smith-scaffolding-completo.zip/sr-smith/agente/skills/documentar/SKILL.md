---
name: documentar
description: Escribe solo lo que el código hace ahora: comandos, entradas y salidas. Borra la frase que el programa no cumple.
---

Escribe solo lo que el código hace ahora: comandos, entradas y salidas. Borra la frase que el programa no cumple.
