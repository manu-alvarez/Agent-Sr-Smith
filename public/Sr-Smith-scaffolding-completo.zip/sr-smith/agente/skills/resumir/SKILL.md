---
name: resumir
description: Resumir. Cierra con qué quedó hecho, qué falta y cómo se comprueba.
---

Cierra con qué quedó hecho, qué falta y cómo se comprueba.
