---
name: rendimiento
description: Mide antes de cambiar. Di qué era lento, qué mediste y cuánto bajó.
---

Mide antes de cambiar. Di qué era lento, qué mediste y cuánto bajó.
