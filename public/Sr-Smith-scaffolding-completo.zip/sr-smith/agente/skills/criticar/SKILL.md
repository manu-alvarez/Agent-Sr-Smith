---
name: criticar
description: Criticar. Señala el fallo concreto del plan o del código. Propón el cambio mínimo. No critiques el estilo sin un efecto.
---

Señala el fallo concreto del plan o del código. Propón el cambio mínimo. No critiques el estilo sin un efecto.
