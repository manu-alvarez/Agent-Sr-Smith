---
name: idiomas
description: Separa los textos de la interfaz. No hardcodees una frase en medio de la lógica si va a traducirse.
---

Separa los textos de la interfaz. No hardcodees una frase en medio de la lógica si va a traducirse.
