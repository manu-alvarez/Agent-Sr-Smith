---
name: git
description: Mira status y diff. Propón un commit con el porqué. En acceso total puedes crearlo. No reescribas historia publicada.
---

Mira status y diff. Propón un commit con el porqué. En acceso total puedes crearlo. No reescribas historia publicada.
