---
name: logs
description: Lee el error real. Cita la línea. No adivines la causa si el mensaje dice otra cosa.
---

Lee el error real. Cita la línea. No adivines la causa si el mensaje dice otra cosa.
