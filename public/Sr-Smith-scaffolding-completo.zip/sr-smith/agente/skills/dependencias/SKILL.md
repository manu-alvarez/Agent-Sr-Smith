---
name: dependencias
description: No añadas un paquete si el proyecto ya resuelve eso. Si lo añades, di para qué y cómo se comprueba.
---

No añadas un paquete si el proyecto ya resuelve eso. Si lo añades, di para qué y cómo se comprueba.
