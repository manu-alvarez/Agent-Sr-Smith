---
name: estimar
description: Estimar. Di qué cuesta en pasos, archivos y pruebas. Si no lo sabes, dilo en vez de inventar un número.
---

Di qué cuesta en pasos, archivos y pruebas. Si no lo sabes, dilo en vez de inventar un número.
