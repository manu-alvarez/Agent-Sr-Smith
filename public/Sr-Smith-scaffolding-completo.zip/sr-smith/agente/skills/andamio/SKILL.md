---
name: andamio
description: Crea la carpeta mínima que ya se puede instalar, probar y arrancar. No dejes un archivo vacío que el programa necesite.
---

Crea la carpeta mínima que ya se puede instalar, probar y arrancar. No dejes un archivo vacío que el programa necesite.
