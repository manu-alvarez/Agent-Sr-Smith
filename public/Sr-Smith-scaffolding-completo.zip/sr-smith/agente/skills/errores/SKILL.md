---
name: errores
description: Cada fallo visible dice qué pasó y qué puede hacer la persona. No ocultes el error para que la pantalla quede verde.
---

Cada fallo visible dice qué pasó y qué puede hacer la persona. No ocultes el error para que la pantalla quede verde.
