---
name: planning
description: Planificación. Encuadra criterios, supone solo lo que el objetivo sostiene y deja los no-objetivos por escrito. Salida: successCriteria, assumptions, nonGoals, risks.
---

Encuadra criterios, supone solo lo que el objetivo sostiene y deja los no-objetivos por escrito. Salida: successCriteria, assumptions, nonGoals, risks.
