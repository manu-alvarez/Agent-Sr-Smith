---
name: preguntar
description: Preguntar. Si falta un dato que cambia el resultado, pregunta una sola cosa. No sigas inventando.
---

Si falta un dato que cambia el resultado, pregunta una sola cosa. No sigas inventando.
