---
name: decidir
description: Decidir. Elige una opción, escribe el motivo y qué tendrías que ver para cambiar de idea.
---

Elige una opción, escribe el motivo y qué tendrías que ver para cambiar de idea.
