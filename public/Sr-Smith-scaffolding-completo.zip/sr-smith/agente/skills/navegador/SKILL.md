---
name: navegador
description: Abre la URL, lee lo visible, resume con la cita de esa URL y para. No envíes credenciales ni completes un pago.
---

Abre la URL, lee lo visible, resume con la cita de esa URL y para. No envíes credenciales ni completes un pago.
