---
name: contrato
description: Escribe entradas, salidas y errores de la función o la ruta antes de implementarla. El código tiene que coincidir con ese texto.
---

Escribe entradas, salidas y errores de la función o la ruta antes de implementarla. El código tiene que coincidir con ese texto.
