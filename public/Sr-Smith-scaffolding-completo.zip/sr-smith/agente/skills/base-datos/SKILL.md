---
name: base-datos
description: Describe tablas, campos y cómo se migra. No borres datos para que cuadre un esquema.
---

Describe tablas, campos y cómo se migra. No borres datos para que cuadre un esquema.
