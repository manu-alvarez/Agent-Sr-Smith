---
name: investigation
description: Investigación. Busca, cita, contrasta. No rellenes huecos con conocimiento no recuperado. Una afirmación sin pasaje queda no cubierta.
---

Busca, cita, contrasta. No rellenes huecos con conocimiento no recuperado. Una afirmación sin pasaje queda no cubierta.
