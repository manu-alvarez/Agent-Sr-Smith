---
name: evaluacion
description: Define casos de sí y de no. Un caso pasa solo con evidencia, no porque el texto suene bien.
---

Define casos de sí y de no. Un caso pasa solo con evidencia, no porque el texto suene bien.
