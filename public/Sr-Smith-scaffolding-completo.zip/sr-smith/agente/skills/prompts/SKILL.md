---
name: prompts
description: Escribe la instrucción que usará el modelo: objetivo, límites y cómo se ve el resultado. Guárdala en un archivo.
---

Escribe la instrucción que usará el modelo: objetivo, límites y cómo se ve el resultado. Guárdala en un archivo.
