---
name: despliegue
description: Escribe los comandos para poner el proyecto en marcha en la máquina indicada. No publiques secretos.
---

Escribe los comandos para poner el proyecto en marcha en la máquina indicada. No publiques secretos.
