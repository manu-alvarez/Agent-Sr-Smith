---
name: cola
description: Si hay trabajos en segundo plano, di qué se encola, qué pasa si falla y cómo se reintenta una sola vez.
---

Si hay trabajos en segundo plano, di qué se encola, qué pasa si falla y cómo se reintenta una sola vez.
