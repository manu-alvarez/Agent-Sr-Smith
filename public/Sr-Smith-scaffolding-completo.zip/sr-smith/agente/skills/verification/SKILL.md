---
name: verification
description: Verificación. Lista criterio, evidencia y pase o fallo. Un criterio sin evidencia falla. accepted es true solo si todos pasan.
---

Lista criterio, evidencia y pase o fallo. Un criterio sin evidencia falla. accepted es true solo si todos pasan.
