---
name: datos
description: Lee CSV o JSON local, cuenta filas, nombra columnas y deja el cálculo repetible. No inventes celdas que no están.
---

Lee CSV o JSON local, cuenta filas, nombra columnas y deja el cálculo repetible. No inventes celdas que no están.
