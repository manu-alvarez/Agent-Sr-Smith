---
name: migracion
description: Mueve datos o código de un sitio a otro. Primero copia, comprueba, y solo luego retira lo viejo.
---

Mueve datos o código de un sitio a otro. Primero copia, comprueba, y solo luego retira lo viejo.
