---
name: interfaz
description: Una acción principal por pantalla. El texto dice qué pasa si se pulsa. No añadas un control que no tiene destino.
---

Una acción principal por pantalla. El texto dice qué pasa si se pulsa. No añadas un control que no tiene destino.
