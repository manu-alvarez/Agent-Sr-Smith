---
name: observacion
description: Deja una forma de ver si el proceso está vivo: un log, un /health o una prueba. Sin eso no hay cierre.
---

Deja una forma de ver si el proceso está vivo: un log, un /health o una prueba. Sin eso no hay cierre.
