---
name: debugging
description: Depuración. Reproduce, aísla, corrige dentro del sandbox y vuelve a comprobar el criterio que falló. Sin la segunda comprobación no hay cierre.
---

Reproduce, aísla, corrige dentro del sandbox y vuelve a comprobar el criterio que falló. Sin la segunda comprobación no hay cierre.
