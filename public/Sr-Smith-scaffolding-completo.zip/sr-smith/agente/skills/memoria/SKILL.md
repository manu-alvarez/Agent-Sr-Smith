---
name: memoria
description: Antes de decidir, lee las notas de esta tarea. Al cerrar, guarda la decisión y el motivo en una nota corta.
---

Antes de decidir, lee las notas de esta tarea. Al cerrar, guarda la decisión y el motivo en una nota corta.
