---
name: api
description: Lee el contrato, llama al método y la ruta pedidos y guarda estado, cuerpo y error. No copies tokens al repositorio.
---

Lee el contrato, llama al método y la ruta pedidos y guarda estado, cuerpo y error. No copies tokens al repositorio.
