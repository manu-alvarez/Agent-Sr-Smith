---
name: explicar
description: Explicar. Cuéntalo como a alguien que abre el proyecto por primera vez. Una frase por idea. Sin jerga si hay una palabra normal.
---

Cuéntalo como a alguien que abre el proyecto por primera vez. Una frase por idea. Sin jerga si hay una palabra normal.
