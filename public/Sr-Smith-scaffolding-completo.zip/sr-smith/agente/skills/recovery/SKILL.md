---
name: recovery
description: Recuperación. Si falla una acción: reintento si queda presupuesto y es idempotente; si no, replan, rollback o escalado. No repitas un borrado.
---

Si falla una acción: reintento si queda presupuesto y es idempotente; si no, replan, rollback o escalado. No repitas un borrado.
