---
name: priorizar
description: Priorizar. Si hay varias cosas, haz primero la que desbloquea al resto. Di cuál dejas para después y por qué.
---

Si hay varias cosas, haz primero la que desbloquea al resto. Di cuál dejas para después y por qué.
