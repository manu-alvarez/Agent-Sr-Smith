---
name: review
description: Antes de cerrar un cambio: lee el diff, ejecuta las pruebas y el typecheck, y rellena el informe. No reescribas un fallo para que quede en verde.
---

Antes de cerrar un cambio: lee el diff, ejecuta las pruebas y el typecheck, y rellena el informe. No reescribas un fallo para que quede en verde.
