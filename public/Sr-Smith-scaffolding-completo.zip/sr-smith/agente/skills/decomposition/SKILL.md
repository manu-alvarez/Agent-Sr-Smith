---
name: decomposition
description: Descomposición. Parte hasta tareas verificables. Paraleliza solo lo independiente. El lote no supera maxParallel.
---

Parte hasta tareas verificables. Paraleliza solo lo independiente. El lote no supera maxParallel.
