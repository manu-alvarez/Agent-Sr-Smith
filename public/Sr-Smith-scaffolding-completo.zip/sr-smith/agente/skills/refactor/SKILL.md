---
name: refactor
description: Cambia la forma del código sin cambiar lo que hace. La prueba de antes y la de después tienen que pasar.
---

Cambia la forma del código sin cambiar lo que hace. La prueba de antes y la de después tienen que pasar.
