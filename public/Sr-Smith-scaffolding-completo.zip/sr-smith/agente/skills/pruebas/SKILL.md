---
name: pruebas
description: Escribe la prueba que falla, luego el cambio mínimo, y vuelve a ejecutarla. Sin la segunda pasada no hay cierre.
---

Escribe la prueba que falla, luego el cambio mínimo, y vuelve a ejecutarla. Sin la segunda pasada no hay cierre.
