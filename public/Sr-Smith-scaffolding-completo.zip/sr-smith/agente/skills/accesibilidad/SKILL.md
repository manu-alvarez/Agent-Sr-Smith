---
name: accesibilidad
description: Comprueba teclado, nombres de botones y contraste. Un control que no se puede usar sin ratón no está terminado.
---

Comprueba teclado, nombres de botones y contraste. Un control que no se puede usar sin ratón no está terminado.
