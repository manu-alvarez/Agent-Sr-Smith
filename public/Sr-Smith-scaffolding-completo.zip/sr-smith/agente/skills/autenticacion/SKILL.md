---
name: autenticacion
description: Di quién entra, qué puede hacer y dónde vive la sesión. No dejes una contraseña en el código.
---

Di quién entra, qué puede hacer y dónde vive la sesión. No dejes una contraseña en el código.
