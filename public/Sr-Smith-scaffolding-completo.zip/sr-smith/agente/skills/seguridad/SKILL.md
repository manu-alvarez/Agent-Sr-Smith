---
name: seguridad
description: Señala permisos, datos sensibles y el fallo concreto. No des un exploit ni pidas desactivar una salvaguarda.
---

Señala permisos, datos sensibles y el fallo concreto. No des un exploit ni pidas desactivar una salvaguarda.
