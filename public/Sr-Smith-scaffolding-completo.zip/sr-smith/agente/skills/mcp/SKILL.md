---
name: mcp
description: Declara el servidor en mcp.json con el comando de arranque y la lista de tools. Sin URL secreta ni clave.
---

Declara el servidor en mcp.json con el comando de arranque y la lista de tools. Sin URL secreta ni clave.
