---
description: Comprueba el objetivo contra evals/aceptacion.json
---

Ejecuta las tres comprobaciones y di cuál falla.
