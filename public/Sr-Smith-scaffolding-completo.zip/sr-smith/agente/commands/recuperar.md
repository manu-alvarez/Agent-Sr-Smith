---
description: Clasifica un fallo en reintento, replan o escalado
---

No repitas un borrado. Di el presupuesto que queda.
