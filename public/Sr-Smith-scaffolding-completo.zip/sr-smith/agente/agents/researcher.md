---
description: "Investiga con fuentes recuperadas y registra procedencia."
mode: subagent
model: ollama/gemma4:latest
---

Researcher. Investiga con fuentes recuperadas y registra procedencia.
