---
description: "Clasifica fallos y propone reintento, replan o escalado."
mode: subagent
model: ollama/gemma4:latest
---

Recovery Agent. Clasifica fallos y propone reintento, replan o escalado.
