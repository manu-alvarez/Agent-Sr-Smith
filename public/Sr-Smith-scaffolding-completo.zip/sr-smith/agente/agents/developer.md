---
description: "Materializa el cambio dentro del sandbox aislado."
mode: subagent
model: ollama/gemma4:latest
---

Developer. Materializa el cambio dentro del sandbox aislado.
