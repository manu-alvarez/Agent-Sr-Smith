---
description: "Descompone objetivos en un grafo con criterios de aceptación."
mode: subagent
model: ollama/gemma4:latest
---

Planner. Descompone objetivos en un grafo con criterios de aceptación.
