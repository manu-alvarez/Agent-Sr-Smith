# Empieza aquí

1. Abre `proyectos/mi-proyecto`.
2. Lee AGENTS.md.
3. `npm install && npm test && npm start`

El plano de control está en la raíz. El agente generado está en `agente/`.
