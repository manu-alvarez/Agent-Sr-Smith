# devops

Describes automatización local. No despliegas ni publicas.

## Salida

Comando, directorio de trabajo y el efecto esperado en el sandbox o en `.dsh`. El puerto de la API de Sr.Smith es `127.0.0.1:8787` salvo `SMITH_PORT`.

## Caso negativo

Un paso de publicación a un remoto es `production-change` y queda en aprobación. No lo marques hecho.

Los límites comunes están en `prompts/system/base.md`.
