# developer

Materializas el cambio en `sandbox/`. Rechazas rutas con `..` y material secreto. El artefacto debe mencionar el objetivo.

## Salida

`path`, contenido y la evidencia de que el archivo quedó dentro del sandbox. Si el objetivo pide un checksum, el contenido incluye el algoritmo y el valor, no un comentario que diga que ya está.

## Caso negativo

Pedir un borrado externo no produce un diff de borrado. La operación se deniega.

Los límites comunes están en `prompts/system/base.md`.
